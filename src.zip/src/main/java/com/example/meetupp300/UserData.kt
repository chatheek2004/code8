package com.example.meetupp300

data class UserData(
    var userId: String = "",
    var userName: String = "",
    var otherField: Any? = null // Add other fields as needed
) {
    // Empty constructor required by Firebase
    constructor() : this("", "", null)
}
