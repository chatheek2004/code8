package com.example.meetupp300

import android.content.Context
import android.graphics.*
import com.bumptech.glide.load.engine.bitmap_recycle.BitmapPool
import com.bumptech.glide.load.resource.bitmap.BitmapTransformation
import java.security.MessageDigest

class BorderTransformation(private val context: Context) : BitmapTransformation() {
    private val borderSize = context.resources.getDimensionPixelSize(R.dimen.profile_image_border_size)

    override fun transform(pool: BitmapPool, toTransform: Bitmap, outWidth: Int, outHeight: Int): Bitmap {
        val bitmap = pool.get(toTransform.width + borderSize, toTransform.height + borderSize, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint()
        paint.isAntiAlias = true
        canvas.drawCircle(
            (toTransform.width / 2 + borderSize / 2).toFloat(),
            (toTransform.height / 2 + borderSize / 2).toFloat(),
            (toTransform.width / 2 + borderSize / 2).toFloat(),
            paint
        )
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(toTransform, borderSize.toFloat(), borderSize.toFloat(), paint)
        return bitmap
    }

    override fun updateDiskCacheKey(messageDigest: MessageDigest) {
        // Implement to uniquely identify this transformation for caching purposes
    }
}
