package com.example.meetupp300


data class UserProfile(
    val email: String = "",
    val username: String = "",
    val gender: String = "",
    val birthdate: String = "",
    val profileImageUrl: String = "" // Add this field for the profile picture URL
)

