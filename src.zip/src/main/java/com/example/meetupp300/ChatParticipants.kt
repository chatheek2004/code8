package com.example.meetupp300

data class ChatParticipant(
    val userId: String,
    val userName: String,
    val email: String
)
