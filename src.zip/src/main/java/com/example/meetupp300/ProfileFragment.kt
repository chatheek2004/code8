
package com.example.meetupp300


import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class ProfileFragment : Fragment() {

    private lateinit var usernameTextView: TextView
    private lateinit var emailTextView: TextView
    private lateinit var genderTextView: TextView
    private lateinit var birthdateTextView: TextView
    private lateinit var profileImageView: ImageView
    private lateinit var database: DatabaseReference
    private lateinit var progressBar: ProgressBar
    private lateinit var currentUserID: String
    private lateinit var storageReference: StorageReference
    private val PICK_IMAGE_REQUEST = 71
    private lateinit var progressDialog: ProgressDialog

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)
        progressBar = view.findViewById(R.id.progressBar)
        usernameTextView = view.findViewById(R.id.usernameTextView)
        emailTextView = view.findViewById(R.id.emailTextView)
        genderTextView = view.findViewById(R.id.genderTextView)
        birthdateTextView = view.findViewById(R.id.birthdateTextView)
        profileImageView = view.findViewById(R.id.profileImageView)
        val logoutButton: Button = view.findViewById(R.id.logoutButton)
        val changeProfileImageButton: Button = view.findViewById(R.id.changeProfilePicButton)

        progressBar.visibility = View.VISIBLE // Show progress bar

        progressDialog = ProgressDialog(requireContext())
        progressDialog.setMessage("Please wait...")
        progressDialog.setCancelable(false)

        // Check if user is authenticated
        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser == null) {
            // User is not authenticated, redirect to login screen
            startActivity(Intent(requireContext(), LoginActivity::class.java))
            requireActivity().finish() // Finish the current activity
            return view // Return to avoid executing further code
        } else {
            currentUserID = currentUser.uid
        }

        database = FirebaseDatabase.getInstance().reference
        storageReference = FirebaseStorage.getInstance().reference

        // Fetch user data from Firebase Realtime Database
        fetchDataFromFirebase()

        // Set click listener for logout button
        logoutButton.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(requireContext(), LoginActivity::class.java))
            requireActivity().finish()
        }

        // Set click listener for change profile image button
        changeProfileImageButton.setOnClickListener {
            // Open image picker
            openImagePicker()
        }

        return view
    }

    private fun fetchDataFromFirebase() {
        database.child("users").child(currentUserID).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val username = snapshot.child("username").value.toString()
                val email = snapshot.child("email").value.toString()
                val gender = snapshot.child("gender").value.toString()
                val birthdate = snapshot.child("birthdate").value.toString()
                val profileImageUrl = snapshot.child("profileImageUrl").value.toString()

                // Populate TextViews with fetched data
                usernameTextView.text = username
                emailTextView.text = email
                genderTextView.text = "Gender: $gender"
                birthdateTextView.text = "Birthdate: $birthdate"

                // Load profile picture into ImageView using Glide library
                Glide.with(requireContext())
                    .load(profileImageUrl)
                    .placeholder(R.drawable.dp)
                    .error(R.drawable.dp)
                    .circleCrop()
                    .into(profileImageView)

                progressBar.visibility = View.GONE
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle database error
                Toast.makeText(requireContext(), "Failed to fetch user data", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun openImagePicker() {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            val filePath = data.data
            if (filePath != null) {
                progressDialog.show() // Show progress dialog before starting upload
                val ref = storageReference.child("profileImages").child("$currentUserID.jpg")
                ref.putFile(filePath)
                    .addOnSuccessListener {
                        // Image uploaded successfully
                        ref.downloadUrl.addOnSuccessListener { uri ->
                            // Update profile image URL in Firebase Realtime Database
                            database.child("users").child(currentUserID).child("profileImageUrl").setValue(uri.toString())
                                .addOnSuccessListener {
                                    // Refresh profile image after successful update
                                    Glide.with(requireContext())
                                        .load(uri)
                                        .placeholder(R.drawable.dp)
                                        .error(R.drawable.dp)
                                        .circleCrop()
                                        .into(profileImageView)
                                    progressDialog.dismiss() // Dismiss progress dialog
                                }
                                .addOnFailureListener {
                                    // Handle failure while updating profile image URL
                                    progressDialog.dismiss() // Dismiss progress dialog in case of failure
                                    Toast.makeText(requireContext(), "Failed to update profile picture", Toast.LENGTH_SHORT).show()
                                }
                        }
                    }
                    .addOnFailureListener {
                        // Handle failure while uploading image to Firebase Storage
                        progressDialog.dismiss() // Dismiss progress dialog in case of failure
                        Toast.makeText(requireContext(), "Failed to upload image", Toast.LENGTH_SHORT).show()
                    }
            }
        }
    }
}
