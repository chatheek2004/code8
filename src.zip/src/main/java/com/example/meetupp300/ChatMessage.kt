package com.example.meetupp300



import java.util.*


data class ChatMessage(
    val senderId: String? = null,
    val receiverId: String? = null,
    val messageText: String? = null,
    val timestamp: Long? = null
)

