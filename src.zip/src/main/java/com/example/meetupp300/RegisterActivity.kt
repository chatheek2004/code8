
package com.example.meetupp300

import android.app.Activity
import android.app.DatePickerDialog
import android.app.ProgressDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.IOException
import java.util.*

class RegistrationActivity : AppCompatActivity() {

    // Firebase Realtime Database reference
    private val database = FirebaseDatabase.getInstance()
    private val usersRef = database.getReference("users")

    // Firebase Authentication
    private lateinit var mAuth: FirebaseAuth

    // Firebase Storage
    private lateinit var storage: FirebaseStorage
    private lateinit var storageReference: StorageReference

    // Views
    private lateinit var selectedBirthdateTextView: TextView

    private lateinit var birthdateButton: Button
    private lateinit var registerButton: Button
    private lateinit var usernameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var confirmPasswordEditText: EditText
    private lateinit var maleRadioButton: RadioButton
    private lateinit var femaleRadioButton: RadioButton
    private lateinit var otherRadioButton: RadioButton
    private lateinit var changeProfileButton: Button

    // Profile image
    private var profileImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance()

        // Initialize Firebase Storage
        storage = FirebaseStorage.getInstance()
        storageReference = storage.reference

        // Initialize views
        selectedBirthdateTextView = findViewById(R.id.birthdateTextView)
        selectedBirthdateTextView.text = ""

        changeProfileButton = findViewById(R.id.changeProfileButton)
        birthdateButton = findViewById(R.id.birthdateButton)
        registerButton = findViewById(R.id.registerButton)
        usernameEditText = findViewById(R.id.usernameEditText)
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText)
        maleRadioButton = findViewById(R.id.maleRadioButton)
        femaleRadioButton = findViewById(R.id.femaleRadioButton)
        otherRadioButton = findViewById(R.id.otherRadioButton)

        // Button click listeners
        changeProfileButton.setOnClickListener {
            // Open gallery to select image
            pickProfileImageFromGallery()
        }

        birthdateButton.setOnClickListener {
            // Show date picker dialog
            pickBirthdateFromCalendar()
        }

        registerButton.setOnClickListener {
            // Register user
            registerUser()
        }
        // "Go to Login" button click listener
        val goToLoginButton = findViewById<Button>(R.id.loginButton)
        goToLoginButton.setOnClickListener {
            // Navigate back to LoginActivity
            startActivity(Intent(this, LoginActivity::class.java))
            finish() // Optional: finish the current registration activity
        }
    }

    // Add the uploadProfileImageAndSaveLink function here
    private fun uploadProfileImageAndSaveLink(userId: String, profileImageUri: Uri) {
        val filename = UUID.randomUUID().toString()
        val ref = storageReference.child("images/$filename")

        ref.putFile(profileImageUri)
            .addOnSuccessListener { taskSnapshot ->
                ref.downloadUrl.addOnSuccessListener { uri ->
                    // Image uploaded successfully, retrieve the download URL
                    val downloadUrl = uri.toString()
                    // Save the download URL to Firebase Realtime Database
                    usersRef.child(userId).child("profileImageUrl").setValue(downloadUrl)
                        .addOnSuccessListener {
                            // Profile image URL saved successfully
                            Log.d("UploadSuccess", "Profile picture URL saved successfully: $downloadUrl")
                            // Continue with other operations or navigate to the next activity
                            // For example, you can navigate to the next activity here
                            startActivity(Intent(this, NextActivity::class.java))
                            finish()
                        }
                        .addOnFailureListener { e ->
                            // Failed to save profile image URL
                            Log.e("UploadError", "Failed to save profile picture URL: ${e.message}")
                            Toast.makeText(this, "Failed to save profile picture URL", Toast.LENGTH_SHORT).show()
                        }
                }
            }
            .addOnFailureListener { e ->
                // Handle unsuccessful upload
                Log.e("UploadError", "Upload failed: ${e.message}")
                Toast.makeText(this, "Upload failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun pickProfileImageFromGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            profileImageUri = data.data
            try {
                val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, profileImageUri)
                val imageView = findViewById<ImageView>(R.id.profileImageView) // Assuming this is your ImageView
                imageView.setImageBitmap(bitmap)
            } catch (e: IOException) {
                e.printStackTrace()
            }

        }
    }

    private fun pickBirthdateFromCalendar() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
                // Set the selected date to the TextView
                val selectedDate = Calendar.getInstance()
                selectedDate.set(year, monthOfYear, dayOfMonth)
                val formattedDate =
                    "${selectedDate.get(Calendar.DAY_OF_MONTH)}-${selectedDate.get(Calendar.MONTH) + 1}-${selectedDate.get(Calendar.YEAR)}"
                selectedBirthdateTextView.text = formattedDate
            },
            year,
            month,
            day
        )
        datePickerDialog.show()
    }


    private fun registerUser() {

        val username = usernameEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()
        val confirmPassword = confirmPasswordEditText.text.toString().trim()
        val gender = when {
            maleRadioButton.isChecked -> "Male"
            femaleRadioButton.isChecked -> "Female"
            otherRadioButton.isChecked -> "Other"
            else -> ""
        }
        val birthdate = selectedBirthdateTextView.text.toString().trim()

        // Validate all fields
        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || gender.isEmpty() || birthdate.isEmpty() || profileImageUri == null) {
            // Check which field is empty and show corresponding error message
            if (username.isEmpty()) {
                usernameEditText.error = "Username is required"
            }
            if (username.length > 10) {
                usernameEditText.error = "Username must be at most 10 characters"
                return
            }

            if (email.isEmpty()) {
                emailEditText.error = "Email is required"
            }
            if (password.isEmpty()) {
                passwordEditText.error = "Password is required"
            }
            if (confirmPassword.isEmpty()) {
                confirmPasswordEditText.error = "Confirm Password is required"
            }
            if (birthdate.isEmpty()) {
                Toast.makeText(this, "Please select your birthdate", Toast.LENGTH_SHORT).show()
            }
            if (profileImageUri == null) {
                Toast.makeText(this, "Please select a profile picture", Toast.LENGTH_SHORT).show()
            }
            if (gender.isEmpty()) {
                Toast.makeText(this, "Please select your gender", Toast.LENGTH_SHORT).show()
            }
            return
        }

        // Check if passwords match
        if (password != confirmPassword) {
            confirmPasswordEditText.error = "Passwords do not match"
            return
        }

        // Validate password length
        if (password.length < 8) {
            passwordEditText.error = "Password must be at least 8 characters"
            return
        }

        // If all fields are correct, show progress dialog
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("Please wait...")
        progressDialog.setCancelable(false)
        progressDialog.show()

        // Register user with Firebase Authentication
        mAuth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                progressDialog.dismiss()
                if (task.isSuccessful) {

                    // User registration successful, save user data to Firebase
                    val currentUser = mAuth.currentUser
                    val userId = currentUser?.uid

                    // Upload profile image to Firebase Storage
                    if (userId != null) {
                        uploadProfileImageAndSaveLink(userId, profileImageUri!!)
                    }

                    // Create user object with other details and save to Firebase Realtime Database
                    userId?.let {
                        val user = User(username, email, gender, birthdate, "") // Replace "" with any other relevant data
                        usersRef.child(it).setValue(user)
                            .addOnSuccessListener {
                                // Data saved successfully
                                Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()
                            }
                            .addOnFailureListener {
                                // Failed to save data
                                Toast.makeText(this, "Failed to register user", Toast.LENGTH_SHORT).show()
                            }
                    }// Redirect user to login page
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish() // Optional: Close the registration activity
                } else {
                    // Registration failed
                    Toast.makeText(this, "Registration failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }

    }




    private fun uploadProfileImageToStorage(userId: String?) {
        profileImageUri?.let { uri ->
            val filename = UUID.randomUUID().toString()
            val ref = storageReference.child("images/$filename")

            ref.putFile(uri)
                .addOnSuccessListener { taskSnapshot ->
                    ref.downloadUrl.addOnSuccessListener { uri ->
                        // Image uploaded successfully, retrieve the download URL
                        val downloadUrl = uri.toString()
                        // Save the download URL or use it as needed
                        // For example, you can store it in Firebase Realtime Database along with other user information
                        userId?.let {
                            usersRef.child(it).child("profileImageUrl").setValue(downloadUrl)
                        }
                        // Log the download URL for debugging
                        Log.d("UploadSuccess", "Profile picture upload successful. Download URL: $downloadUrl")
                    }
                }
                .addOnFailureListener { e ->
                    // Handle unsuccessful upload
                    Toast.makeText(this@RegistrationActivity, "Upload failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }




    companion object {
        private const val PICK_IMAGE_REQUEST = 71
    }
}