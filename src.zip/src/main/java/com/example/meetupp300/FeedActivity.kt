package com.example.meetupp300

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.util.*

class FeedActivity : AppCompatActivity() {

    // Firebase Realtime Database reference
    private val database = FirebaseDatabase.getInstance()
    private val feedsRef = database.getReference("feeds")
    private val usersRef = database.getReference("users")

    // Firebase Authentication
    private lateinit var mAuth: FirebaseAuth

    // Firebase Storage
    private lateinit var storage: FirebaseStorage
    private lateinit var storageReference: StorageReference

    // Views
    private lateinit var feedEditText: EditText
    private lateinit var imageViewFeed: ImageView
    private lateinit var uploadFeedButton: Button
    private lateinit var selectImageButton: Button
    private lateinit var feedRecyclerView: RecyclerView
    private lateinit var feedAdapter: FeedAdapter

    // Feed data
    private val feedList = ArrayList<Feed>()

    // Constants
    private val PICK_IMAGE_REQUEST = 71
    private var imageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_feed)

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance()

        // Initialize Firebase Storage
        storage = FirebaseStorage.getInstance()
        storageReference = storage.reference

        // Initialize views
        feedEditText = findViewById(R.id.feedEditText)
        imageViewFeed = findViewById(R.id.imageViewFeed)
        uploadFeedButton = findViewById(R.id.uploadFeedButton)
        selectImageButton = findViewById(R.id.selectImageButton)
        feedRecyclerView = findViewById(R.id.feedRecyclerView)

        // RecyclerView setup
        feedAdapter = FeedAdapter(feedList)
        feedRecyclerView.layoutManager = LinearLayoutManager(this)
        feedRecyclerView.adapter = feedAdapter

        // Button click listeners
        uploadFeedButton.setOnClickListener {
            // Upload feed
            uploadFeed()
        }

        selectImageButton.setOnClickListener {
            // Open gallery to select image
            openGallery()
        }

        // Listen for changes in feeds
        feedsRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // Clear previous feed data
                feedList.clear()

                // Populate feed list with new data
                for (postSnapshot in snapshot.children) {
                    val feed = postSnapshot.getValue(Feed::class.java)
                    feed?.let {
                        // Fetch username and profile image URL from "users" node
                        val userRef = usersRef.child(it.userId)
                        userRef.addListenerForSingleValueEvent(object : ValueEventListener {
                            override fun onDataChange(userSnapshot: DataSnapshot) {
                                if (userSnapshot.exists()) {
                                    val user = userSnapshot.getValue(User::class.java)
                                    user?.let { userData ->
                                        it.username = userData.username
                                        it.profileImageUrl = userData.profileImageUrl
                                    }
                                }
                                // Add the feed to the list after fetching user data
                                feedList.add(it)
                                // Notify adapter of changes
                                feedAdapter.notifyDataSetChanged()
                            }

                            override fun onCancelled(error: DatabaseError) {
                                // Handle error
                                Toast.makeText(this@FeedActivity, "Error fetching user data: ${error.message}", Toast.LENGTH_SHORT).show()
                            }
                        })
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
                Toast.makeText(this@FeedActivity, "Error fetching feeds: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun uploadFeed() {
        val feedText = feedEditText.text.toString().trim()
        val currentUser = mAuth.currentUser
        val userId = currentUser?.uid

        // Show progress dialog
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("Uploading feed...")
        progressDialog.setCancelable(false)
        progressDialog.show()

        // Check if both text and image are provided
        if (imageUri != null && feedText.isNotEmpty()) {
            // Upload image to Firebase Storage
            val imageRef = storageReference.child("images/${UUID.randomUUID()}")
            imageRef.putFile(imageUri!!)
                .addOnSuccessListener { taskSnapshot ->
                    // Get the download URL of the uploaded image
                    imageRef.downloadUrl.addOnSuccessListener { uri ->
                        // Save the feed with image URL and text to Firebase Realtime Database
                        val timestamp = System.currentTimeMillis()
                        val feed = Feed(userId ?: "", feedText, uri.toString(), timestamp)
                        saveFeedToDatabase(feed, progressDialog)
                    }
                }
                .addOnFailureListener { e ->
                    // Handle image upload failure
                    progressDialog.dismiss()
                    Toast.makeText(this, "Failed to upload image: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        } else if (imageUri != null) {
            // If only image is provided, save only image feed to Firebase Realtime Database
            val imageRef = storageReference.child("images/${UUID.randomUUID()}")
            imageRef.putFile(imageUri!!)
                .addOnSuccessListener { taskSnapshot ->
                    // Get the download URL of the uploaded image
                    imageRef.downloadUrl.addOnSuccessListener { uri ->
                        // Save the feed with only image URL to Firebase Realtime Database
                        val timestamp = System.currentTimeMillis()
                        val feed = Feed(userId ?: "", "", uri.toString(), timestamp)
                        saveFeedToDatabase(feed, progressDialog)
                    }
                }
                .addOnFailureListener { e ->
                    // Handle image upload failure
                    progressDialog.dismiss()
                    Toast.makeText(this, "Failed to upload image: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        } else if (feedText.isNotEmpty()) {
            // If only text is provided, save only text feed to Firebase Realtime Database
            val timestamp = System.currentTimeMillis()
            val feed = Feed(userId ?: "", feedText, "", timestamp)
            saveFeedToDatabase(feed, progressDialog)
        } else {
            // If neither image nor text is provided, show an error message
            progressDialog.dismiss()
            Toast.makeText(this, "Please enter feed text or select an image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveFeedToDatabase(feed: Feed, progressDialog: ProgressDialog) {
        val feedId = feedsRef.push().key
        feedId?.let { id ->
            feedsRef.child(id).setValue(feed)
                .addOnSuccessListener {
                    // Feed uploaded successfully
                    progressDialog.dismiss()
                    Toast.makeText(this, "Feed uploaded successfully", Toast.LENGTH_SHORT).show()

                    // Clear input fields
                    feedEditText.text.clear()

                    // Clear selected image
                    imageUri = null
                    imageViewFeed.setImageURI(null)
                    imageViewFeed.visibility = ImageView.GONE
                }
                .addOnFailureListener {
                    // Failed to upload feed
                    progressDialog.dismiss()
                    Toast.makeText(this, "Failed to upload feed", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            imageUri = data.data
            imageViewFeed.setImageURI(imageUri)
            imageViewFeed.visibility = ImageView.VISIBLE
        }
    }
}
