
package com.example.meetupp300
import android.graphics.*
import com.squareup.picasso.Transformation
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.*

class FeedAdapter(private val feedList: List<Feed>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val TEXT_ONLY_VIEW_TYPE = 1
    private val IMAGE_ONLY_VIEW_TYPE = 2
    private val TEXT_AND_IMAGE_VIEW_TYPE = 3

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            TEXT_ONLY_VIEW_TYPE -> {
                val textOnlyView = inflater.inflate(R.layout.text_only_feed_item, parent, false)
                TextOnlyViewHolder(textOnlyView)
            }
            IMAGE_ONLY_VIEW_TYPE -> {
                val imageOnlyView = inflater.inflate(R.layout.image_only_feed_item, parent, false)
                ImageOnlyViewHolder(imageOnlyView)
            }
            TEXT_AND_IMAGE_VIEW_TYPE -> {
                val textAndImageView = inflater.inflate(R.layout.text_and_image_feed_item, parent, false)
                TextAndImageViewHolder(textAndImageView)
            }
            else -> throw IllegalArgumentException("Invalid view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val feed = feedList[position]
        when (holder.itemViewType) {
            TEXT_ONLY_VIEW_TYPE -> {
                val textHolder = holder as TextOnlyViewHolder
                textHolder.bindTextFeed(feed)
            }
            IMAGE_ONLY_VIEW_TYPE -> {
                val imageHolder = holder as ImageOnlyViewHolder
                imageHolder.bindImageFeed(feed)
            }
            TEXT_AND_IMAGE_VIEW_TYPE -> {
                val textAndImageHolder = holder as TextAndImageViewHolder
                textAndImageHolder.bindTextAndImageFeed(feed)
            }
        }
    }

    override fun getItemCount(): Int = feedList.size

    override fun getItemViewType(position: Int): Int {
        val feed = feedList[position]
        return when {
            feed.feedText?.isNotEmpty() == true && feed.imageUrl.isNullOrEmpty() -> TEXT_ONLY_VIEW_TYPE
            feed.feedText.isNullOrEmpty() && feed.imageUrl?.isNotEmpty() == true -> IMAGE_ONLY_VIEW_TYPE
            else -> TEXT_AND_IMAGE_VIEW_TYPE
        }

    }

    inner class TextOnlyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindTextFeed(feed: Feed) {
            val textFeedTextView = itemView.findViewById<TextView>(R.id.textFeedTextView)
            textFeedTextView.text = feed.feedText
            loadProfile(feed.userId, itemView)
            loadTimestamp(feed.timestamp, itemView)
        }
    }

    inner class ImageOnlyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindImageFeed(feed: Feed) {
            val imageFeedImageView = itemView.findViewById<ImageView>(R.id.imageFeedImageView)
            if (!feed.imageUrl.isNullOrEmpty()) {
                Picasso.get().load(feed.imageUrl).into(imageFeedImageView)
            } else {
                // Handle empty or invalid image URL
                Picasso.get().load(R.drawable.error).into(imageFeedImageView)
            }

            loadProfile(feed.userId, itemView)
            loadTimestamp(feed.timestamp, itemView)
        }
    }

    inner class TextAndImageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindTextAndImageFeed(feed: Feed) {
            val textFeedTextViewCombined = itemView.findViewById<TextView>(R.id.textFeedTextViewCombined)
            val imageFeedImageViewCombined = itemView.findViewById<ImageView>(R.id.imageFeedImageViewCombined)

            // Set text as caption
            textFeedTextViewCombined.text = feed.feedText

            // Load image

            if (!feed.imageUrl.isNullOrEmpty()) {
                Picasso.get().load(feed.imageUrl).into(imageFeedImageViewCombined)
            } else {
                // Handle empty or invalid image URL
                Picasso.get().load(R.drawable.error).into(imageFeedImageViewCombined)
            }

            loadProfile(feed.userId, itemView)
            loadTimestamp(feed.timestamp, itemView)
        }
    }

    private fun loadProfile(userId: String, itemView: View) {
        val databaseReference = FirebaseDatabase.getInstance().getReference("users").child(userId)
        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val profileImageUrl = snapshot.child("profileImageUrl").value.toString()
                val profileImageView = itemView.findViewById<ImageView>(R.id.profileImageView)
                Picasso.get().load(profileImageUrl).transform(CircleTransformation()).into(profileImageView)


                val usernameTextView = itemView.findViewById<TextView>(R.id.usernameTextView)
                val username = snapshot.child("username").value.toString()
                usernameTextView.text = username
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
                Toast.makeText(itemView.context, "Failed to load user data: ${error.message}", Toast.LENGTH_SHORT).show()
            }

        })
    }

    private fun loadTimestamp(timestamp: Long, itemView: View) {
        val timestampTextView = itemView.findViewById<TextView>(R.id.timestampTextView)
        timestampTextView.text = getFormattedTimestamp(timestamp)
    }

    private fun getFormattedTimestamp(timestamp: Long): String {
        val dateFormat = SimpleDateFormat("HH:mm | dd.MM.yyyy", Locale.getDefault())
        return dateFormat.format(Date(timestamp))
    }
    class CircleTransformation : Transformation {
        override fun transform(source: Bitmap): Bitmap {
            val size = Math.min(source.width, source.height)

            val x = (source.width - size) / 2
            val y = (source.height - size) / 2

            val squaredBitmap = Bitmap.createBitmap(source, x, y, size, size)
            if (squaredBitmap != source) {
                source.recycle()
            }

            val bitmap = Bitmap.createBitmap(size, size, source.config)

            val canvas = Canvas(bitmap)
            val paint = Paint()
            val shader = BitmapShader(squaredBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            paint.shader = shader
            paint.isAntiAlias = true

            val radius = size / 2f
            canvas.drawCircle(radius, radius, radius, paint)

            squaredBitmap.recycle()
            return bitmap
        }

        override fun key(): String {
            return "circle"
        }
    }
}
