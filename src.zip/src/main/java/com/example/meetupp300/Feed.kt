package com.example.meetupp300

data class Feed(
    val userId: String,
    val feedText: String,
    val imageUrl: String?,
    val timestamp: Long, // Timestamp as a Long value
    var username: String? = null,
    var profileImageUrl: String? = null
) {
    // Default constructor required for Firebase
    constructor() : this("", "", null, 0L)
}
