package com.example.meetupp300
import android.util.Log

class ChatManager(private val listener: ChatListener) {

    interface ChatListener {
        fun onMessageReceived(message: String)
        fun onError(error: String)
    }

    fun sendMessage(message: String) {
        // Here you would implement the logic to send the message
        // For demonstration purposes, we'll log the message
        Log.d("ChatManager", "Sending message: $message")
    }

    fun receiveMessage(message: String) {
        // Notify the listener that a message has been received
        listener.onMessageReceived(message)
    }

    fun handleError(error: String) {
        // Notify the listener about the error
        listener.onError(error)
    }
}
