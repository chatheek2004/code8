package com.example.meetupp300




import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class LocationForDistance(
    val latitude: Double = 0.0,
    val longitude: Double = 0.0
) {
    // Add default (no-argument) constructor
    constructor() : this(0.0, 0.0)
}
