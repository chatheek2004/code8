package com.example.meetupp300

// UserAdapter.kt
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth

class UserAdapter(private val userList: List<String>) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.user_item, parent, false)
        return UserViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val currentUserUid = FirebaseAuth.getInstance().currentUser?.uid
        val selectedUser = userList[position]

        // Check if the selected user is not the current user
        if (selectedUser != currentUserUid) {
            holder.itemView.findViewById<Button>(R.id.chatButton).visibility = View.VISIBLE
            // Set click listener for the chat button
            holder.itemView.findViewById<Button>(R.id.chatButton).setOnClickListener {
                initiateChatWithUser(holder.itemView.context, selectedUser)
            }
        } else {
            // If the selected user is the current user, hide the chat button
            holder.itemView.findViewById<Button>(R.id.chatButton).visibility = View.GONE
        }

        // Bind other user data to the view holder
        holder.bind(selectedUser)
    }

    override fun getItemCount(): Int {
        return userList.size
    }

    class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(user: String) {
            // Bind user data to the views in the item layout
            itemView.findViewById<TextView>(R.id.userNameTextView).text = user
        }
    }

    private fun initiateChatWithUser(context: Context, selectedUser: String) {
        val intent = Intent(context, ChatActivity::class.java)
        intent.putExtra("otherUserId", selectedUser)
        context.startActivity(intent)
    }
}
