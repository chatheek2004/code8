
package com.example.meetupp300


import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class ProfileActivity : AppCompatActivity() {

    private lateinit var usernameTextView: TextView
    private lateinit var emailTextView: TextView
    private lateinit var genderTextView: TextView
    private lateinit var birthdateTextView: TextView
    private lateinit var profileImageView: ImageView
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        usernameTextView = findViewById(R.id.usernameTextView)
        emailTextView = findViewById(R.id.emailTextView)
        genderTextView = findViewById(R.id.genderTextView)
        birthdateTextView = findViewById(R.id.birthdateTextView)
        profileImageView = findViewById(R.id.profileImageView)
        val logoutButton: Button = findViewById(R.id.logoutButton)

        // Check if user is authenticated
        if (FirebaseAuth.getInstance().currentUser == null) {
            // User is not authenticated, redirect to login screen
            startActivity(Intent(this, LoginActivity::class.java))
            finish() // Finish the current activity
            return // Return to avoid executing further code
        }

        database = FirebaseDatabase.getInstance().reference

        // Fetch user data from Firebase Realtime Database
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        userId?.let {
            database.child("users").child(it).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val username = snapshot.child("username").value.toString()
                    val email = snapshot.child("email").value.toString()
                    val gender = snapshot.child("gender").value.toString()
                    val birthdate = snapshot.child("birthdate").value.toString()
                    val profileImageUrl = snapshot.child("profileImageUrl").value.toString()

                    val emailLabel: TextView = findViewById(R.id.emailTextView)
                    emailLabel.setTypeface(null, Typeface.BOLD)



                    // Populate TextViews with fetched data
                    usernameTextView.text = username
                    emailTextView.text = email
                    genderTextView.text = "Gender: $gender"
                    birthdateTextView.text = "Birthdate: $birthdate"

                    // Load profile picture into ImageView using Glide library
                    Glide.with(this@ProfileActivity)
                        .load(profileImageUrl)
                        .placeholder(R.drawable.dp)
                        .error(R.drawable.dp)
                        .circleCrop()
                        .into(profileImageView)
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle database error
                }
            })
        }

        // Logout Button Click Listener
        logoutButton.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this@ProfileActivity, LoginActivity::class.java))
            finish()
        }
    }
}


